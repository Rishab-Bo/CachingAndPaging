#include "generate_students.c"
#include "server.c"

int main() {
    generate();
    server();
    return 0;
}