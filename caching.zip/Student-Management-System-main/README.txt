OS PROJECT: Student Management Program

Name:               Roll No:
Cecily Ambooken     IIB2022003
Rakim Middya        IIT2022255
Rishab Bohra        IIB2022004 
Veerathu Sindhu     IIB2022006


Coded parts:
Cecily Ambooken - Regular operation generator and Search() in main_memory.c
Rishab Bohra    - Student_Registration and UpdateFile() method in main_memory.c
Veerathu Sindhu - Random operation generator and most of main_memory.c (update/add_node/remove_node etc.)
Rakim Middya    - File-Handling (searchFile, delete, etc.), Compiled and shell script

FILE HANDLING:  Rakim and Rishab
LINKED LIST  :  Sindhu and Cecily