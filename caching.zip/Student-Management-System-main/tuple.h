#ifndef TUPLE
#define TUPLE

typedef struct Tuple
{
    char type[10];
    int stdID;
    int opID;
    int roomNo;
}tuple;

#endif