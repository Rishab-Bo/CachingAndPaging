README

Each file is using 1 workload respective to the name of the file. All algorithms needed are being used for all workloads.
note - possibility of error with 1 workload, rerun the code a couple of times if it happens.

Attached is also folder store which stores data on cache size and respective hit rate.

custom algorithm - simulate_hybrid