#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

#define NUMBER_OF_FRAMES 100
int printonce = 0;

unsigned int randval() {
    unsigned int randval;
    FILE *f;
    f = fopen("/dev/random", "r");
    fread(&randval, sizeof(randval), 1, f);
    fclose(f);
    return randval;
}

void clear_file(const char* filename) {
    remove(filename);
    FILE *in = fopen(filename, "w");
    if (in != NULL) {
        fclose(in);
    }
}

void print_to_file(const char* filename, float hit_ratio, int cache_size) {
    FILE *out = fopen(filename, "a");
    if (out != NULL) {
        fprintf(out, "%d %.2f\n", cache_size, hit_ratio * 100);
        printf("%d %.2f\n", cache_size, hit_ratio * 100);
        fclose(out);
    }
}

void simple_workload(int requests[], int num_of_requests) {
    srand(time(NULL));
    for (int i = 0; i < num_of_requests; i++) {
        requests[i] = randval() % NUMBER_OF_FRAMES;
    }
}


void simulate_FIFO(int requests[], int num_of_requests, int cache_size) {
    int queue[cache_size];
    int hits = 0;
    int front = 0;
    int rear = 0;

    for (int i = 0; i < num_of_requests; i++) {
        bool hit = false;

        for (int j = 0; j < rear; j++) {
            if (queue[j] == requests[i]) {
                hit = true;
                hits++;
                break;
            }
        }

        if (!hit) {
            if (rear < cache_size) {
                queue[rear++] = requests[i];
            } else {
                for (int j = 0; j < cache_size - 1; j++) {
                    queue[j] = queue[j + 1];
                }
                queue[cache_size - 1] = requests[i];
            }
        }
    }

    float hit_ratio = (float)hits / num_of_requests;
    print_to_file("FIFO.txt", hit_ratio, cache_size);
}


void simulate_FIFOforHybrid(int requests[], int num_of_requests, int cache_size) {
    int queue[cache_size];
    int hits = 0;
    int front = 0;
    int rear = 0;

    for (int i = 0; i < num_of_requests; i++) {
        bool hit = false;

        for (int j = 0; j < rear; j++) {
            if (queue[j] == requests[i]) {
                hit = true;
                hits++;
                break;
            }
        }

        if (!hit) {
            if (rear < cache_size) {
                queue[rear++] = requests[i];
            } else {
                for (int j = 0; j < cache_size - 1; j++) {
                    queue[j] = queue[j + 1];
                }
                queue[cache_size - 1] = requests[i];
            }
        }
    }

    float hit_ratio = (float)hits / num_of_requests;
    print_to_file("hybrid.txt", hit_ratio, cache_size);
}

void simulate_optimal(int requests[], int num_of_requests, int cache_size) {
    int queue[cache_size];
    int hits = 0;
    int map[NUMBER_OF_FRAMES][num_of_requests];
    for (int i = 0; i < num_of_requests; i++) {
        map[requests[i]][i] = i + 1;
    }

    for (int i = 0; i < cache_size; i++) {
        queue[i] = -1;
    }

    for (int i = 0; i < num_of_requests; i++) {
        bool hit = false;

        for (int j = 0; j < cache_size; j++) {
            if (queue[j] == requests[i]) {
                hit = true;
                hits++;
                break;
            }
        }

        if (!hit) {
            int idx = -1;
            if (i >= cache_size) {
                int mx = -1;
                for (int j = 0; j < cache_size; j++) {
                    int k;
                    for (k = i; k < num_of_requests; k++) {
                        if (map[queue[j]][k] == 0) {
                            break;
                        }
                    }
                    if (k == num_of_requests) {
                        idx = j;
                        break;
                    } else if (map[queue[j]][k] > mx) {
                        mx = map[queue[j]][k];
                        idx = j;
                    }
                }
            } else {
                idx = i;
            }
            if (idx != -1) {
                queue[idx] = requests[i];
            }
        }
        map[requests[i]][i] = 0;
    }
    float hit_ratio = (float)hits / num_of_requests;
    print_to_file("optimal.txt", hit_ratio, cache_size);
}

void simulate_random(int requests[], int num_of_requests, int cache_size) {
    int queue[cache_size];
    int hits = 0;

    for (int i = 0; i < num_of_requests; i++) {
        bool hit = false;

        for (int j = 0; j < cache_size; j++) {
            if (queue[j] == requests[i]) {
                hit = true;
                hits++;
                break;
            }
        }

        if (!hit) {
            int replace_idx = rand() % cache_size;
            queue[replace_idx] = requests[i];
        }
    }

    float hit_ratio = (float)hits / num_of_requests;
    print_to_file("hybrid.txt", hit_ratio, cache_size);
}

typedef struct {
    int start;
    int end;
    bool hasPattern;
} SegmentInfo;

SegmentInfo* segments = NULL;
int segmentSize = 1;
int segmentCapacity = 0;

int generateRandomNumber(int min, int max) {
    return rand() % (max - min + 1) + min;
}

int* generatePattern(int patternLength, int minNumber, int maxNumber) {
    int* pattern = (int*)malloc(patternLength * sizeof(int));
    if (pattern == NULL) {
        printf("Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < patternLength; ++i) {
        pattern[i] = generateRandomNumber(minNumber, maxNumber);
    }

    return pattern;
}

int* generate_workload_with_random(int totalRequests, int minPatternRepeats, int maxPatternRepeats, int minPatternLength, int maxPatternLength) {
    int* requests = (int*)malloc(totalRequests * sizeof(int));
    if (requests == NULL) {
        printf("Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    int currentRequests = 0;
    while (currentRequests < totalRequests) {
        int patternRepeats = generateRandomNumber(minPatternRepeats, maxPatternRepeats);
        int patternLength = generateRandomNumber(minPatternLength, maxPatternLength);

        if (currentRequests + patternRepeats * patternLength > totalRequests) {
            patternRepeats = (totalRequests - currentRequests) / patternLength;
            if (patternRepeats == 0) {
                patternLength = totalRequests - currentRequests;
                patternRepeats = 1;
            }
        }

        int* pattern = generatePattern(patternLength, 1, NUMBER_OF_FRAMES);

        for (int i = 0; i < patternRepeats; ++i) {
            for (int j = 0; j < patternLength; ++j) {
                requests[currentRequests++] = pattern[j];
            }
        }

        // THIS IS TO ADD RANDOM REQUESTS BETWEEN PATTERNS GENERATED ABOVE
        if (currentRequests < totalRequests) {
            int randomLength = generateRandomNumber(1, NUMBER_OF_FRAMES);
            for (int k = 0; k < randomLength && currentRequests < totalRequests; ++k) {
                requests[currentRequests++] = generateRandomNumber(0, NUMBER_OF_FRAMES);
            }
        }

        free(pattern);
    }

    return requests;
}

void detectPatterns(int* workload, int totalRequests, int patternLength) {
    int currentIndex = 0;

    while (currentIndex < totalRequests) {
        int sequenceCount = 0;
        int nextIndex = currentIndex + patternLength;

        while (nextIndex < totalRequests) {
            int i;
            for (i = 0; i < patternLength; ++i) { //GOING THROUGH EVERY ELEMENT IN FRONT (TILL U GET PATTERN SIZE) 
                if (workload[currentIndex + i] != workload[nextIndex + i]) {
                    break;
                }
            }
            //IF WE FIND A SITUATION WHERE ABOVE INDICES HAVE EQUAL VALUE, IT MEANS THERES A CHANCE IT CAN BE THE START OF A PATTERN
            if (i == patternLength) {
                sequenceCount++;
                nextIndex += patternLength; // CHECKING IF ITS A FULL PATTERN AND NOT JUST ACCIDENTAL SAME NUMBER
            } else {
                break;
            }
        }

        //IF PATTERN IS DETECTED
        if (sequenceCount > 0) {

            if (segmentSize!=1){
            segments[segmentSize-1].end = currentIndex-1; //SETTING INFORMATION FOR SEGMENTS WITHOUT PATTERN
            segments[segmentSize-1].hasPattern = false;
            segmentSize++;
            }

            printf("Pattern detected from index %d to %d, repeating %d times\n", currentIndex, currentIndex + patternLength - 1, sequenceCount + 1);
            segments = (SegmentInfo*)realloc(segments, segmentSize * sizeof(SegmentInfo));
            if (segments == NULL) {
                printf("Memory allocation failed. Exiting...");
            }
            segments[segmentSize-1].start = currentIndex; //SETTING INFO FOR SEGMENTS WITH PATTERN
            segments[segmentSize-1].end = currentIndex + (patternLength * (sequenceCount + 1)) - 1;
            segments[segmentSize-1].hasPattern = true;
            segmentSize++;

            

            segments[segmentSize-1].start = nextIndex;
            currentIndex = nextIndex;

        } else {
            currentIndex++;
        }
    }

    
    
}


void simulate_hybrid(int requests[], int num_of_requests, int cache_size, int pattern_length) {
    printf("entered function\n");

    if (printonce==0){
        detectPatterns(requests, num_of_requests, pattern_length);  //ONLY DOING THIS ONCE, SINCE MAIN CALLS IT A LOT OF TIMES BUT WE ONLY NEED TO DETECT PATTERN ONCE
        printf("segments detected\n");

        segments[segmentSize-1].start = segments[segmentSize-2].end+1;
        segments[segmentSize-1].end = num_of_requests-1; //SETTING INFO FOR LAST SEGMENT
        segments[segmentSize-1].hasPattern = false;

        printf("Printing segments:\n");
        for (int i = 0; i < segmentSize; i++) {
            printf("Segment %d:\n", i + 1); 
            printf("Start: %d\n", segments[i].start);
            printf("End: %d\n", segments[i].end);
            printf("Has Pattern: %s\n", segments[i].hasPattern ? "true" : "false");
            printf("\n");
        }
        printonce++;
    }

    int num_of_segments = segmentSize;

    for (int i = 0; i < num_of_segments; i++) {
        printf("pattern is %s \n", segments[i].hasPattern ? "True" : "False");
        if (segments[i].hasPattern) {
            // THERE IS PATTERN
            int segment_length = segments[i].end - segments[i].start + 1;
            printf("Simulating random for segment %d to %d\n", segments[i].start, segments[i].end);
            simulate_random(&requests[segments[i].start], segment_length, cache_size);
        } else {
            //NO PATTERN
            int segment_length = segments[i].end - segments[i].start + 1;
            printf("Simulating FIFO for segment %d to %d\n", segments[i].start, segments[i].end);

            if (segment_length > 0) {
                simulate_FIFOforHybrid(&requests[segments[i].start], segment_length, cache_size);
            }
        }
    }
}


int main() {
    srand(time(NULL));

    int totalRequests = 10000;
    int minPatternRepeats = 2;
    int maxPatternRepeats = 10;
    int patternLength = 600; 
    int cache_size = 30;
    int requests[totalRequests];

    // int* workload = generate_workload_with_random(totalRequests, minPatternRepeats, maxPatternRepeats, patternLength, patternLength);
    
    simple_workload(requests, totalRequests);
    // if (workload != NULL) {
    //     printf("Generated Workload: ");
    //     for (int i = 0; i < totalRequests; ++i) {
    //         printf("%d ", workload[i]);
    //     }
    //     printf("\n");
    // }

    segments = (SegmentInfo*)realloc(segments, segmentSize * sizeof(SegmentInfo));
            if (segments == NULL) {
                printf("Memory allocation failed. Exiting...");
            }

    for (int i=3; i<100; i++){
        cache_size = i;
        simulate_optimal(requests, totalRequests, cache_size);
        simulate_FIFO(requests, totalRequests, cache_size);
        simulate_hybrid(requests, totalRequests, cache_size, patternLength);
    }
    
    // free(workload);
    free(segments);
    return 0;
}
